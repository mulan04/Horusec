defmodule BuiltWithElixirWeb.LayoutViewTest do
  use BuiltWithElixirWeb.ConnCase, async: true
end
