defmodule BuiltWithElixirWeb.PageViewTest do
  use BuiltWithElixirWeb.ConnCase, async: true
end
