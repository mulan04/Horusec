defmodule BuiltWithElixirWeb.PageView do
  use BuiltWithElixirWeb, :view
end
