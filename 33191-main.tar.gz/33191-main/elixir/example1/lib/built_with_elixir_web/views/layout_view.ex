defmodule BuiltWithElixirWeb.LayoutView do
  use BuiltWithElixirWeb, :view
end
