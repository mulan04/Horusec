---
name: Feature request
about: Suggest a new feature for this project
labels: feature
assignees: ''

---

<!-- Please only use this template for submitting new feature or enhancement requests -->

**What would you like to be added**:

**Why is this needed**:
